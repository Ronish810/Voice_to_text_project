import os
from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
#from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash

 
from django.http import JsonResponse
from tempfile import NamedTemporaryFile
from moviepy.editor import VideoFileClip
import speech_recognition as sr
import assemblyai as aai
import json
import requests  
  


# Create your views here.
def homePage(request):
    return render(request, "index.html")

User = get_user_model()

def SignUp(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')

        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')

    return render(request, "signup.html")

def Login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('dashboard')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render(request, "login.html")


def Deshboard(request):
    return render(request, "home.html")

def LogoutPage(request):
    logout(request)
    return redirect('login')

def View_Profile(request):
    return render(request, "view_profile.html")

def realtime(request):
    return render(request, "realtime.html")
def vtotext(request):
    return render(request, "videototext.html")
def atotext(request):
    return render(request, "audiofiletotext.html")



###########################################################################

from django.http import JsonResponse
from moviepy.editor import VideoFileClip
import tempfile
import assemblyai as aai

def convert_video_to_text(request):
    if request.method == 'POST' and request.FILES.get('video_file'):
        video_file = request.FILES['video_file']

        # Handle the uploaded video file
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as temp_video_file:
            for chunk in video_file.chunks():
                temp_video_file.write(chunk)

        # Convert the uploaded video to an audio file (e.g., WAV format)
        audio_file_path = convert_video_to_audio(temp_video_file.name)

        if audio_file_path:
            # Transcribe the audio using the AssemblyAI API
            transcribed_text = audio_to_text(audio_file_path)

            # Return the transcribed text as JSON response
            response_data = {'transcribed_text': transcribed_text}

            return JsonResponse({
                "status": "200",
                "data": response_data
            })
            
    return render(request, 'videototext.html', {'response_data': ''})

def convert_video_to_audio(video_file_path):
    try:
        video = VideoFileClip(video_file_path)
        audio_file_path = video_file_path + ".wav"
        video.audio.write_audiofile(audio_file_path, codec='pcm_s16le')
        return audio_file_path
    except Exception as e:
        print("Error converting video to audio:", str(e))
        return None

#############################################################################################


 # Import filedialog from tkinter for file selection

# Set your AssemblyAI API key
aai.settings.api_key = "af38052d8a7741e882f97bb671013a7b"

def convert_audio_file_to_text(request): 
    if request.method == 'POST':
        image_file = request.FILES['audio_file']
        print('Printing Image file')
        print(image_file)
        # Transcribe the audio using the AssemblyAI API
        transcribed_text = audio_to_text(image_file.temporary_file_path())

        # Return the transcribed text as JSON response
        response_data = {'transcribed_text': transcribed_text}
         
        return JsonResponse({
            "status":"200",
            "data":  response_data
        })
        # return render(request, 'audiofiletotext.html', {'response_data': response_data['transcribed_text']})  # Display the initial form
    
    return render(request, 'audiofiletotext.html', {'response_data': ''})  # Display the initial form

def audio_to_text(audio_file_path):
    transcriber = aai.Transcriber()
    transcript = transcriber.transcribe(audio_file_path)
    return transcript.text



############################################################################################################################################

def convert_voice_to_text(request):
    if request.method == 'POST':
        try:
            # The code for voice-to-text conversion using speech_recognition
            r = sr.Recognizer()
            with sr.Microphone() as source:
                print("Listening...")
                r.adjust_for_ambient_noise(source)

                audio = r.listen(source)
                text = r.recognize_google(audio)
                return JsonResponse({'transcribed_text': text})
        except sr.UnknownValueError:
            return JsonResponse({'error': 'Speech recognition could not understand audio'})
        except sr.RequestError as e:
            return JsonResponse({'error': f'Could not request results from the speech recognition service; {e}'})
    
    return JsonResponse({'error': 'Invalid request'})

def text_editor(request):
    return render(request, 'realtime.html')
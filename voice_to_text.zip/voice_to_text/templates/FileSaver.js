saveButton.addEventListener("click", function () {
    const textToSave = textInput.value;
    const selectedFormat = formatSelect.value;

    switch (selectedFormat) {
        case "txt":
            // Save as TXT
            const blobTxt = new Blob([textToSave], { type: 'text/plain;charset=utf-8' });
            saveAs(blobTxt, 'document.txt');
            break;

        case "pdf":
            // Save as PDF using jsPDF
            const pdf = new jsPDF();
            pdf.text(textToSave, 10, 10);
            const pdfBlob = pdf.output('blob');
            saveAs(pdfBlob, 'document.pdf');
            break;

        case "docx":
            // Save as Word (requires Docxtemplater and related libraries)
            const doc = new Docxtemplater();
            doc.loadFromUrl('template.docx'); // Load a template file if needed
            doc.setData({ content: textToSave }); // Set the data
            doc.render(); // Render the document
            const wordBlob = doc.getZip().generate({ type: 'blob' });
            saveAs(wordBlob, 'document.docx');
            break;

        default:
            alert("Please select a valid format.");
            break;
    }
});

"""
URL configuration for voice_to_text project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from vot import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.homePage),
    path('signup/', views.SignUp, name='signup'),
    path('login/', views.Login, name='login'),
    path('dashboard/', views.Deshboard, name='dashboard'),
    path('dashboard/view-profile/', views.View_Profile),
    path('dashboard/realtime/', views.realtime),
    #path('dashboard/videototext/', views.vtotext),
    # path('dashboard/audiofiletotex/', views.atotext),
    path('dashboard/logout/',views.LogoutPage,name='logout'),
    path('dashboard/videototext/', views.convert_video_to_text,name='convert_video_to_text'),
    path('dashboard/audiofiletotext/', views.convert_audio_file_to_text,name='convert_audio_file_to_text'),
    path('dashboard/voicetotext/', views.convert_voice_to_text, name='convert_voice_to_text')
    ]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)